<script>
  // Play the sound when the page loads
  window.onload = function() {
    playButtonReadout('Page loaded'); // Read out 'Page loaded' on page load
  };

  // Theme toggle functionality
  const themeToggle = document.getElementById('themeToggle');
  themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark');
    playButtonReadout('Theme'); // Read out 'Theme' when the theme is toggled
  });

  // Sound toggle functionality
  const soundToggle = document.getElementById('soundToggle');
  let soundOn = true;

  soundToggle.addEventListener('click', () => {
    soundOn = !soundOn;
    soundToggle.textContent = soundOn ? 'Sound: On' : 'Sound: Off';
  });

  // Read out button text when a tab is clicked
  const tabs = document.querySelectorAll('.tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      if (soundOn) {
        const buttonText = tab.textContent;
        playButtonReadout(buttonText);
      }
    });
  });

  // Function to read out the text of a button
  function playButtonReadout(text) {
    const synth = window.speechSynthesis;
    const utterance = new SpeechSynthesisUtterance(text);
    synth.speak(utterance);
  }
</script>